// Servidor simples de Sombras de Eldora Online
// Requisitos: Node.js 18+ e dependência ws (npm install)
const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer } = require("ws");
const PORT = Number(process.env.PORT || 8080);
const ROOT = path.join(__dirname, "public");
const CONFIG = { cols:15, rows:10, maxPlayers:20, moveCooldown:90, playerDamage:6, enemyDamage:4, bossDamage:7 };
const baseMap = [
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,2,2,0,0,0,0,0,2,2,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,1,1,1,0,0,0,0,0,1],
[1,0,0,0,0,0,1,0,1,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
[1,0,0,0,0,0,0,0,0,0,0,0,4,0,1],
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];
const mapPath=path.join(ROOT,"map.json");
let map=baseMap.map(r=>r.slice());
if(fs.existsSync(mapPath)){try{const parsed=JSON.parse(fs.readFileSync(mapPath,"utf8"));if(validMap(parsed.tiles))map=parsed.tiles}catch{}}
let players = new Map();
let enemies = [{id:"slime-a",x:4,y:4,hp:14,maxHP:14,boss:false},{id:"slime-b",x:10,y:7,hp:14,maxHP:14,boss:false},{id:"guardian",x:12,y:8,hp:30,maxHP:30,boss:true}];
let nextId=1;
function validMap(t){return Array.isArray(t)&&t.length===CONFIG.rows&&t.every(r=>Array.isArray(r)&&r.length===CONFIG.cols&&r.every(v=>Number.isInteger(v)&&v>=0&&v<=4))}
function send(ws,obj){if(ws.readyState===1)ws.send(JSON.stringify(obj))}
function broadcast(obj){const data=JSON.stringify(obj);for(const ws of wss.clients)if(ws.readyState===1)ws.send(data)}
function snapshot(){const p={};for(const [id,v] of players)p[id]={id,name:v.name,x:v.x,y:v.y,hp:v.hp,maxHP:v.maxHP,level:v.level,xp:v.xp,gold:v.gold,potions:v.potions};return {players:p,enemies,map}}
function publish(){broadcast({type:"state",state:snapshot()})}
function say(text){broadcast({type:"message",text})}
function blocked(x,y,id){if(y<0||y>=map.length||x<0||x>=map[y].length||[1,2,3].includes(map[y][x]))return true;for(const [pid,p] of players)if(pid!==id&&p.x===x&&p.y===y)return true;return false}
function adjacent(a,b){return Math.abs(a.x-b.x)+Math.abs(a.y-b.y)===1}
const server=http.createServer((req,res)=>{let pathname=decodeURIComponent((req.url||"/").split("?")[0]);if(pathname==="/")pathname="/index.html";const file=path.join(ROOT,pathname);if(!file.startsWith(ROOT)){res.writeHead(403);return res.end("Forbidden")}fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end("Not found")}const ext=path.extname(file);res.writeHead(200,{"Content-Type":ext===".html"?"text/html; charset=utf-8":ext===".json"?"application/json; charset=utf-8":"application/octet-stream","Cache-Control":"no-store"});res.end(data)})});
const wss=new WebSocketServer({server});
wss.on("connection",ws=>{
  if(players.size>=CONFIG.maxPlayers){send(ws,{type:"error",text:"Servidor cheio."});ws.close();return}
  let id=null;
  ws.on("message",raw=>{
    let msg;try{msg=JSON.parse(raw.toString())}catch{return}
    if(msg.action==="join"){
      if(id)return;
      id="p"+nextId++;
      const name=String(msg.name||"Aventureiro").replace(/[<>]/g,"").slice(0,16)||"Aventureiro";
      players.set(id,{id,name,x:1,y:1,hp:30,maxHP:30,level:1,xp:0,gold:0,potions:2,lastMove:0});
      send(ws,{type:"welcome",id});say(`${name} entrou em Eldora.`);publish();return;
    }
    if(!id||!players.has(id))return;
    const p=players.get(id);
    if(msg.action==="move"){
      const now=Date.now();if(now-p.lastMove<CONFIG.moveCooldown)return;p.lastMove=now;
      const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[msg.direction];if(!d)return;
      const nx=p.x+d[0],ny=p.y+d[1];if(blocked(nx,ny,id))return;p.x=nx;p.y=ny;
      if(map[ny][nx]===4){p.x=1;p.y=1;send(ws,{type:"message",text:"O portal levou você de volta ao acampamento."})}
      publish();return;
    }
    if(msg.action==="attack"){
      const e=enemies.find(e=>e.hp>0&&adjacent(p,e));if(!e){send(ws,{type:"message",text:"Nenhum inimigo ao alcance."});return}
      e.hp-=CONFIG.playerDamage;
      if(e.hp<=0){p.gold+=e.boss?15:2;p.xp+=e.boss?15:5;say(e.boss?`${p.name} derrotou o Guardião Sombrio!`:`${p.name} derrotou uma criatura.`);
        while(p.xp>=10){p.xp-=10;p.level++;p.maxHP+=5;p.hp=Math.min(p.maxHP,p.hp+10);send(ws,{type:"message",text:`Você alcançou o nível ${p.level}!`})}
        if(e.boss){e.hp=e.maxHP;say("O Guardião renascerá em breve no protótipo.")}
      } else {p.hp=Math.max(0,p.hp-(e.boss?CONFIG.bossDamage:CONFIG.enemyDamage));if(p.hp===0){p.hp=p.maxHP;p.x=1;p.y=1;send(ws,{type:"message",text:"Você foi derrotado e voltou ao acampamento."})}}
      publish();return;
    }
    if(msg.action==="rest"){p.hp=Math.min(p.maxHP,p.hp+6);publish();return}
    if(msg.action==="potion"){if(p.potions>0&&p.hp<p.maxHP){p.potions--;p.hp=Math.min(p.maxHP,p.hp+12)}publish();return}
    if(msg.action==="setMap"){
      // Prototype creator permission: any connected user can update map. Restrict this before public deployment.
      if(!validMap(msg.tiles)){send(ws,{type:"error",text:"Mapa inválido."});return}
      map=msg.tiles.map(r=>r.slice());fs.writeFile(mapPath,JSON.stringify({name:"Mapa de Eldora",tiles:map},null,2),err=>{if(err)send(ws,{type:"error",text:"Mapa aplicado na sessão, mas não foi salvo em disco."});else say("O mapa foi atualizado por um criador.")});publish();return;
    }
  });
  ws.on("close",()=>{if(id&&players.has(id)){const n=players.get(id).name;players.delete(id);say(`${n} saiu de Eldora.`);publish()}});
});
server.listen(PORT,"0.0.0.0",()=>console.log(`Sombras de Eldora Online: http://localhost:${PORT}`));
